<?php
/**
 * Created by IntelliJ IDEA.
 * User: Nikolay Chervyakov 
 * Date: 20.08.2014
 * Time: 13:01
 */


namespace App\Rest\Controller;


use App\Rest\Controller;

class OrderAddresses extends Controller
{
    protected $modelName = 'OrderAddress';
} 