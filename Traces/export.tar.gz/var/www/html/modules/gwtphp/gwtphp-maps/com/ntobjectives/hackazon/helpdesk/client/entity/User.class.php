<?php
class User implements IsSerializable {
	/**
	 * 
	 * @var int
	*/
	public $id;
	
	/**
	 * 
	 * @var string
	*/
	public $first_name;
	
	/**
	 * 
	 * @var string
	*/
	public $username;
	
	/**
	 * 
	 * @var string
	*/
	public $last_name;
	
	/**
	 * 
	 * @var string
	*/
	public $photo;
	
}
