<div class="section">
    <div class="container">
        <?php
        include("search_product_items.php"); ?>
    </div>
</div>
