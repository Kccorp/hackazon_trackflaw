<div class="field panel panel-green">
    <div class="panel-heading">
        <?php $_($fieldName . ' (' . $source . ')'); ?>
    </div>
    <div class="panel-body">
        <div class="field-vulnerabilities context-subsection">
            <?php echo $vulnerabilities; ?>
        </div>
    </div>
</div>