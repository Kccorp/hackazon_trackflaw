<hr>
<footer>
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; NTObjectives 2014</p>
        </div>
    </div>
</footer>

<script type="text/x-template" id="tplAlertContent">
    <div class="text-center">
        <a href="#" class="btn btn-primary js-yes">Yes</a>
        <a href="#" class="btn btn-danger js-no">No</a>
    </div>
</script>