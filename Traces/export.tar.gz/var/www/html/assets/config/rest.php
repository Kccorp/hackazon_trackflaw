<?php
return array (
  'excluded_models' => 
  array (
    0 => 'BaseModel',
    1 => 'Model',
    2 => 'OrderAddress',
  ),
  'auth' => 
  array (
    'type' => 'token',
    'session' => false,
  ),
);
