<?php
return array(
    'fields' => [
    ],

    'vulnerabilities' => [
        'referrer' => [
            'enabled' => true,
        ],

        'XMLExternalEntity' => true
    ]
);