<?php
return array (
  'default' => 
  array (
    'user' => 'hackazon',
    'password' => 'MDEXMenxEKF',
    'driver' => 'PDOV',
    'connection' => 'mysql:host=hackazon_db;port=3306;dbname=hackazon',
    'db' => 'hackazon',
    'host' => 'hackazon_db',
    'port' => '3306',
  ),
);
