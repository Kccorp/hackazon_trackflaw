<?php
return array (
  'default' => 
  array (
    'type' => 'sendmail',
    'sendmail_command' => NULL,
    'mail_parameters' => NULL,
    'hostname' => 'localhost',
    'port' => '25',
    'username' => NULL,
    'password' => NULL,
    'encryption' => NULL,
    'timeout' => NULL,
  ),
);
